<!DOCTYPE html> 
<html lang="en">

<head>
    <!-- Header Start  -->
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <meta http-equiv="X-UA-Compatible" content="ie=edge,chrome=1" /> 
    <title>Easebuzz | !404</title>
    <meta name="title" content="Easebuzz Privacy Policy | Easebuzz"/>
    <meta name="description" content="The Easebuzz payment gateway solution for India is a reliable, developer-friendly API with affordable pricing. We places a high value on information privacy and confidentiality.">
    <meta name="keywords" content="Easebuzz Privacy Policy,
    Privacy and confidentiality">
    <meta name=”robots” content=”noindex,nofollow”>
    <link rel="canonical" href="https://easebuzz.in/404_new/"/>

    <style>
        .header-transparent.header .nav
        {
            background:linear-gradient( 
            115deg, #3E16E1 0%, #AA2589 100%)
        }
        header .nav.sticky
        {
            background: #fff!important;
        }
       .error-spacing
        {
            padding:300px 0 150px 0px;
        }
        .home-banner-btn
        {
          background-color:#3E16E1;
          color: #fff;
          padding: 10px 45px 10px 45px;
          border-radius: 20px;
          margin-top: 20px!important;
        }
        .home-banner-btn:hover
        {
          color: #fff;
        }
        .gseamless-info{margin-bottom: 30px;}
        .gseamless-right
        {
          margin-top: 50px;
        }
        .gseamless-right h4
        {
          font-size: 46px;
        }
        .gseamless-right a
        {
          color: #8971ff;
        }
        .oops
        {
          font-size: 24px;
        }
        .small-text.hy-link 
        {
          margin-bottom: 10px;
        }
        @media only screen and (max-width:800px){
           .error-spacing
            {
                padding:134px 20px 70px 20px;
            }
            .img-creative{width: 100%;}
        }
    </style>
    
    
    <!--
        Allows control over where resources are loaded from.
        Place as early in the <head> as possible, as the tag
        only applies to resources that are declared after it.
        -->
    <!--Name of web application (only should be used if the website is used as an app)
        -->
    <meta name="application-name" content="Naskay" />
    <!--Theme Color for Chrome, Firefox OS and Opera
        -->
    <meta name="theme-color" content="#1f3f99" />
    <!--Disable automatic detection and formatting of possible phone numbers
        -->
        <meta name="format-detection" content="telephone=no"/>
        <meta name="msapplication-tap-highlight" content="no"/>
        <meta name="renderer" content="webkit|ie-comp|ie-stand"/>
        <link rel="apple-touch-icon" href="/static/base/assets_aug_2021/img/easebuzz/home/favicon.png"/>
        <link rel="shortcut icon" href="/static/base/assets_aug_2021/img/easebuzz/home/favicon.png"/>
        <meta name="keywords" content=""/>
        <meta name="google-site-verification" content="z6p068Md2tRbJN6pMfQXSYfPfjmjLXXkj5gNk2C0LZE" />
        <meta name="google-site-verification" content="V8y_rGSUFmcWj6E-d0G3FX11x7AQ3GMuTL6uJslXQIU" />
        <meta name="google-site-verification" content="-0vYdDRxEsTRHXtcCSOG7BivwbLDFMdI9g6WRoEGoJc" />
        
        <!-- <link rel="preconnect" href="https://fonts.googleapis.com"> -->
        <!-- <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin> -->
        <link href="/static/base/assets_aug_2021/css/dm-sans.css" rel="stylesheet">
        <!-- <link rel="preconnect" href="https://fonts.googleapis.com"> -->
        <!-- <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin> -->
        <link href="/static/base/assets_aug_2021/css/sen.css" rel="stylesheet">
        <!-- <link rel="stylesheet" href="/static/base/assets_aug_2021/css/semantic_ui_min.css"/> -->
        <!-- <link rel="stylesheet" href="/static/base/assets_aug_2021/css/main.css"/> -->
        <!-- <link rel="stylesheet" href="/static/base/assets_aug_2021/css/custom.css"/> -->
        <!-- <link rel="stylesheet" href="https://unpkg.com/swiper/swiper-bundle.min.css" /> -->
        
        <!-- <link rel="canonical" href="/index.html"/> -->
    <!-- <script>
        (function(i, s, o, g, r, a, m) {
            i['GoogleAnalyticsObject'] = r;
            i[r] = i[r] || function() {
                (i[r].q = i[r].q || []).push(arguments)
            }, i[r].l = 1 * new Date();
            a = s.createElement(o),
                m = s.getElementsByTagName(o)[0];
            a.async = 1;
            a.src = g;
            m.parentNode.insertBefore(a, m)
        })(window, document, 'script', '//www.google-analytics.com/analytics.js', 'ga');

        ga('create', 'UA-67009256-1', 'auto');
        ga('send', 'pageview');
    </script> -->

    <!-- Facebook Conversion Code for Easebuzz.in -->
    <script>
        ! function(f, b, e, v, n, t, s) {
            if (f.fbq) return;
            n = f.fbq = function() {
                n.callMethod ?
                    n.callMethod.apply(n, arguments) : n.queue.push(arguments)
            };
            if (!f._fbq) f._fbq = n;
            n.push = n;
            n.loaded = !0;
            n.version = '2.0';
            n.queue = [];
            t = b.createElement(e);
            t.async = !0;
            t.src = v;
            s = b.getElementsByTagName(e)[0];
            s.parentNode.insertBefore(t, s)
        }(window,
            document, 'script', 'https://connect.facebook.net/en_US/fbevents.js');

        fbq('init', '859002937495697');
        fbq('track', "PageView");
        fbq('track', 'Purchase', {
            value: '0.00',
            currency: 'INR'
        });
    </script>
    <!-- <script type='text/javascript'>
        window.smartlook||(function(d) {
          var o=smartlook=function(){ o.api.push(arguments)},h=d.getElementsByTagName('head')[0];
          var c=d.createElement('script');o.api=new Array();c.async=true;c.type='text/javascript';
          c.charset='utf-8';c.src='https://rec.smartlook.com/recorder.js';h.appendChild(c);
          })(document);
          smartlook('init', '2945dde7e71992ade78369d5a3a83f7ce7ed5b28');
    </script> -->
    <noscript><img height="1" width="1" style="display:none" alt=""
        src="https://www.facebook.com/tr?id=859002937495697&ev=PageView&noscript=1"
        /></noscript>
    <!-- Google Tag Manager -->
    <script>
        (function(w, d, s, l, i) {
            w[l] = w[l] || [];
            w[l].push({
                'gtm.start': new Date().getTime(),
                event: 'gtm.js'
            });
            var f = d.getElementsByTagName(s)[0],
                j = d.createElement(s),
                dl = l != 'dataLayer' ? '&l=' + l : '';
            j.async = true;
            j.src =
                'https://www.googletagmanager.com/gtm.js?id=' + i + dl;
            f.parentNode.insertBefore(j, f);
        })(window, document, 'script', 'dataLayer', 'GTM-5NJLRXT');
    </script>
    <!-- End Google Tag Manager -->

    <!-- Google Tag Manager -->
    <script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
    new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
    j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
    'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
    })(window,document,'script','dataLayer','GTM-NNCQNLN');
    </script>
    <!-- End Google Tag Manager -->


    <script>
        (function(i, s, o, g, r, a, m) {
            i['GoogleAnalyticsObject'] = r;
            i[r] = i[r] || function() {
                (i[r].q = i[r].q || []).push(arguments)
            }, i[r].l = 1 * new Date();
            a = s.createElement(o),
                m = s.getElementsByTagName(o)[0];
            a.async = 1;
            a.src = g;
            m.parentNode.insertBefore(a, m)
        })(window, document, 'script', '//www.google-analytics.com/analytics.js', 'ga');

        ga('create', 'UA-67009256-1', 'auto');
        ga('send', 'pageview');
    </script>

    <!-- Meta Pixel Code -->
    <script>
        !function(f,b,e,v,n,t,s)
        {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
        n.callMethod.apply(n,arguments):n.queue.push(arguments)};
        if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
        n.queue=[];t=b.createElement(e);t.async=!0;
        t.src=v;s=b.getElementsByTagName(e)[0];
        s.parentNode.insertBefore(t,s)}(window, document,'script',
        'https://connect.facebook.net/en_US/fbevents.js');
        fbq('init', '445989603978483');
        fbq('track', 'PageView');
        </script>
        <noscript><img height="1" width="1" style="display:none"
        src="https://www.facebook.com/tr?id=445989603978483&ev=PageView&noscript=1"
        /></noscript>
    <!-- End Meta Pixel Code -->
    
    <!-- Global site tag (gtag.js) - Google Ads: 10847349030 -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=AW-10847349030"></script>
    <script>
    window.dataLayer = window.dataLayer || [];
    function gtag(){dataLayer.push(arguments);}
    gtag('js', new Date());

    gtag('config', 'AW-10847349030');
    </script>

     
    <!-- Header End -->
</head>

<body ng-app="ebzApp">
    <!-- Google Tag Manager (noscript) -->
    <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-5NJLRXT"
        height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
    <!-- End Google Tag Manager (noscript) -->

    <!-- Google Tag Manager (noscript) -->
    <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-NNCQNLN"
    height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
    <!-- End Google Tag Manager (noscript) -->

    <!-- Header Start  -->
     
        

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" href="/static/base/assets_aug_2021/css/semantic_ui_min.css"/>
    <link rel="stylesheet" href="/static/base/assets_aug_2021/css/main.css?version=3"/>
    <link rel="stylesheet" href="/static/base/assets_aug_2021/css/custom.css?version=3"/>
    <link rel="stylesheet" href="/static/base/assets_aug_2021/css/header_custom.css?version=3"/>
</head>
<body>
    
<!-- Header-->

<header class="header header-transparent svg-white" id="header">
    <nav class="nav nav-wrap mobile active">
        <div class="container">
            <div class="row">
                <div class="nav-wrapper col-12">
                    <div class="nav-header">
                        <span class="signup-menu">
                            <span class="menu__item header-sign-up">
                                
                                
                                <a class="sign-up sign-up-w" href="/merchant/signup/">Sign Up</a>
                                
                            </span>
                            <div class="menu-icon">
                                <span class="line"></span>
                                <span class="line"></span>
                                <span class="line"></span>
                            </div>
                        </span>

                        <div class="logo d-flex align-items-center">
                            <a class="navbar-link header-brand-logo" href="/">
                                <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="" height="35" viewBox="0 0 144 35">
                                    <defs>
                                      <clipPath id="clip-path">
                                        <rect id="Rectangle_2336" data-name="Rectangle 2336" width="144" height="35" transform="translate(6292 -233)" fill="none"/>
                                      </clipPath>
                                    </defs>
                                    <g id="Mask_Group_1" data-name="Mask Group 1" transform="translate(-6292 233)" clip-path="url(#clip-path)">
                                      <g id="Easebuzz_Logo_Unit_-_White_Text" data-name="Easebuzz Logo Unit - White Text" transform="translate(6291.25 -226.348)">
                                        <path id="Path_7063" data-name="Path 7063" d="M31.885,21.044V2.063A1.137,1.137,0,0,1,33.018.93H45.967l-.015,3.421H36.259V9.235h8.418v3.354H36.229v4.989l9.873.015v3.451Z" fill="#091B49"/>
                                        <path id="Path_7064" data-name="Path 7064" d="M51.946,21.322a5.256,5.256,0,0,1-3.451-1.14,3.978,3.978,0,0,1-1.388-3.256,4.107,4.107,0,0,1,1.748-3.586c1.178-.825,3.031-1.253,5.574-1.283l1.786-.03v-.863a1.934,1.934,0,0,0-.585-1.515,2.439,2.439,0,0,0-1.778-.525,3.852,3.852,0,0,0-1.7.42,2.163,2.163,0,0,0-1.08,1.4H47.715A4.033,4.033,0,0,1,49.59,7.495a8.187,8.187,0,0,1,4.449-1.11q3.3,0,4.674,1.223A4.19,4.19,0,0,1,60.1,10.931V21.044H56.388V18.568a4.489,4.489,0,0,1-1.846,2.153A5.351,5.351,0,0,1,51.946,21.322ZM53.3,18.651a3.12,3.12,0,0,0,2.483-1.223,1.9,1.9,0,0,0,.428-1.185V14.112l-1.455.03a7.835,7.835,0,0,0-1.883.24,3.1,3.1,0,0,0-1.418.75,1.855,1.855,0,0,0-.525,1.388,1.916,1.916,0,0,0,.683,1.568A2.59,2.59,0,0,0,53.3,18.651Z" fill="#091B49"/>
                                        <path id="Path_7065" data-name="Path 7065" d="M67.754,21.322a8.649,8.649,0,0,1-2.888-.488,5.8,5.8,0,0,1-2.341-1.56A5.122,5.122,0,0,1,61.3,16.505h3.511a2.185,2.185,0,0,0,1.163,1.6,4.351,4.351,0,0,0,3.624.068,1.212,1.212,0,0,0,.72-1.14,1.136,1.136,0,0,0-.428-.93,3.092,3.092,0,0,0-1.388-.525l-2.521-.525a7.023,7.023,0,0,1-3.068-1.365,3.452,3.452,0,0,1-1.163-2.753A4.041,4.041,0,0,1,63.275,7.69a6.816,6.816,0,0,1,4.494-1.305A6.921,6.921,0,0,1,72,7.57a3.889,3.889,0,0,1,1.621,3.279H70.237A1.9,1.9,0,0,0,69.4,9.565a2.882,2.882,0,0,0-1.681-.458,3.573,3.573,0,0,0-1.733.375,1.228,1.228,0,0,0-.683,1.14,1.007,1.007,0,0,0,.555.9,6.113,6.113,0,0,0,1.718.555l2.333.525a5.564,5.564,0,0,1,2.431,1.14,3.9,3.9,0,0,1,1.14,1.583,4.3,4.3,0,0,1,.308,1.47,3.846,3.846,0,0,1-1.681,3.339A7.372,7.372,0,0,1,67.754,21.322Z" fill="#091B49"/>
                                        <path id="Path_7066" data-name="Path 7066" d="M78.85,14.78a3.961,3.961,0,0,0,.788,2.626,2.776,2.776,0,0,0,2.258.975,3.636,3.636,0,0,0,1.816-.443,2.37,2.37,0,0,0,1.1-1.463h3.646a4.913,4.913,0,0,1-1.223,2.618,6.428,6.428,0,0,1-2.356,1.658,7.446,7.446,0,0,1-2.881.57,7.612,7.612,0,0,1-3.744-.893,6.357,6.357,0,0,1-2.513-2.543,7.925,7.925,0,0,1-.9-3.864,8.887,8.887,0,0,1,.818-3.879A6.486,6.486,0,0,1,78.024,7.4a7.6,7.6,0,0,1,7.435-.083A5.685,5.685,0,0,1,87.7,9.9a8.908,8.908,0,0,1,.765,3.8V14.78Zm-.015-2.416h5.852a3.512,3.512,0,0,0-.72-2.228,2.588,2.588,0,0,0-2.176-.915,2.736,2.736,0,0,0-1.606.458,3,3,0,0,0-1,1.185A3.247,3.247,0,0,0,78.835,12.364Z" fill="#091B49"/>
                                        <path id="Path_7067" data-name="Path 7067" d="M97.853,21.322a5.117,5.117,0,0,1-2.341-.473,4.267,4.267,0,0,1-1.455-1.223,5.6,5.6,0,0,1-.788-1.53v2.948h-3.4V.375h3.271a.8.8,0,0,1,.8.8V8.613a4.235,4.235,0,0,1,1.636-1.568,5.286,5.286,0,0,1,2.678-.653,5.028,5.028,0,0,1,4.186,1.936,8.6,8.6,0,0,1,1.523,5.454,8.931,8.931,0,0,1-1.553,5.492A5.387,5.387,0,0,1,97.853,21.322ZM96.968,18.4a2.658,2.658,0,0,0,2.161-1.073,5.8,5.8,0,0,0,.878-3.616,5.366,5.366,0,0,0-.833-3.309,2.669,2.669,0,0,0-2.236-1.073q-2.982,0-3.008,4.381a6.509,6.509,0,0,0,.75,3.616A2.583,2.583,0,0,0,96.968,18.4Z" fill="#091B49"/>
                                        <path id="Path_7068" data-name="Path 7068" d="M110.645,21.322a6.5,6.5,0,0,1-2.581-.54A5.205,5.205,0,0,1,106,19.2a4.09,4.09,0,0,1-.818-2.588V6.662h4.051v9.43a2.2,2.2,0,0,0,.653,1.643,2.619,2.619,0,0,0,1.913.638,2.771,2.771,0,0,0,1.891-.615,2.2,2.2,0,0,0,.705-1.741V6.662H118.4V21.044h-3.526V18.193a3.648,3.648,0,0,1-.945,1.951,3.585,3.585,0,0,1-1.568.915A6.012,6.012,0,0,1,110.645,21.322Z" fill="#091B49"/>
                                        <path id="Path_7069" data-name="Path 7069" d="M119.73,21.044V19.161a1.121,1.121,0,0,1,.233-.683L126.8,9.505H120.09V6.662h11.621V8.928l-7.09,9.273h7.127v2.836H119.73Z" fill="#091B49"/>
                                        <path id="Path_7070" data-name="Path 7070" d="M132.731,21.044V19.161a1.121,1.121,0,0,1,.233-.683l6.842-8.973h-6.715V6.662h11.621V8.928l-7.09,9.273h7.127v2.836H132.731Z" fill="#091B49"/>
                                        <path id="Path_7071" data-name="Path 7071" d="M3.3,9.31H20.249l-1.906,3.466a2.267,2.267,0,0,1-1.988,1.178H.75Z" fill="#85E6C4"/>
                                        <path id="Path_7072" data-name="Path 7072" d="M10.211,16.213H27.158l-1.906,3.466a2.267,2.267,0,0,1-1.988,1.178H7.66Z" fill="#6d44e5"/>
                                        <path id="Path_7073" data-name="Path 7073" d="M10.211,2.4H27.158L25.253,5.867a2.267,2.267,0,0,1-1.988,1.178H7.66Z" fill="#517CE3"/>
                                      </g>
                                    </g>
                                  </svg>
                            </a>
                        </div>
                    </div>
                    <div class="hamb-overlay"></div>
                    <div class="menu">
                        <ul class="menu-list menu-list--left mb-header-nav">
                            <li class="menu__item ui dropdown header-select-dropdown">
                                <input type="hidden" name="Products" />
                                <div class="d-flex align-items-center menu__link">
                                    <div class="default nav-dropdown-text pr-3">Products</div><svg width="9" height="12" viewBox="0 0 9 12" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M4.53001 11.8646L8.04725 8.96791C8.3155 8.72826 8.34112 8.34398 8.13459 8.09175C7.92807 7.83951 7.51066 7.79795 7.25845 8.00451L4.7563 10.0671L4.7563 0.62071C4.7563 0.277903 4.47841 -1.65801e-07 4.13562 -1.80784e-07C3.79282 -1.95769e-07 3.51493 0.277903 3.51493 0.62071L3.51493 10.0671L1.01277 8.00451C0.760582 7.79795 0.349019 7.84444 0.13664 8.09175C-0.0823807 8.34676 -0.0282721 8.76141 0.223976 8.96791L3.74121 11.8646C4.00635 12.0531 4.27362 12.037 4.53001 11.8646Z" fill="white"/>
</svg>

                                </div>
                                <div class="menu transition hidden header-select-dropdown__menu">
                                    <div class="skew-pane"></div>
                                    <div class="item p-0 nav-menu-lists">
                                        <div class="nav-menu-lists-item">
                                            <h2 class="p-4 my-0">Payments</h2>
                                        </div>
                                        <ul class="p-2 px-md-4 py-md-2 nav-menu-list-item">
                                            <!-- SAMPLE DATA-->
                                            <li class="py-2 py-md-3 d-flex">
                                                <a class="d-flex align-items-center flex-row">
                                                    <img class="nav-icon" src="/static/base/assets_aug_2021/img/navMenu/1PaymentGateway.svg" alt="Payment Gateway" />
                                                    <div class="flex-column">
                                                        <div class="d-flex align-items-center flex-row">
                                                            <a href="/online-payment-gateway-India/"><p class="mb-0 product_id" onclick="redirectTo('/online-payment-gateway-India')">
                                                                Payment Gateway</p></a>
                                                            
                                                            <div class="docs-link ml-4 p-2 d-block" onclick="getApiDocsFor('PaymentGateWay')" href="#">
                                                                API Docs <img class="link-icon ml-2" src="/static/base/assets_aug_2021/img/navMenu/arrow-right.svg" alt="" />
                                                            </div>
                                                        </div>
                                                        <p class="nav-desc">Accept payments with an API integration</p>
                                                    </div>
                                                </a>
                                            </li>
                                            <li class="py-2 py-md-3 d-flex">
                                                <a class="d-flex align-items-center flex-row"><img class="nav-icon" src="/static/base/assets_aug_2021/img/navMenu/2PaymentLink.svg" alt="Payment Link" />
                                                    <div class="flex-column">
                                                        <div class="d-flex align-items-center flex-row">
                                                            <a href="/payment-links/"><p class="mb-0 product_id" onclick="redirectTo('/payment-links')">
                                                                Payment Link</p></a>
                                                         <!-- <div class="docs-link ml-4 p-2 d-block" href="javascript:void(0)" onclick="getApiDocsFor()">
                                                                API Docs <img class="link-icon ml-2" src="/static/base/assets_aug_2021/img/navMenu/arrow-right.svg"
                                                                 alt="" /></div> -->
                                                        </div>
                                                        <p class="nav-desc">Accept payments via a link</p>
                                                    </div>
                                                </a>
                                            </li>
                                            <li class="py-2 py-md-3 d-flex">
                                                <a class="d-flex align-items-center flex-row"><img class="nav-icon" src="/static/base/assets_aug_2021/img/navMenu/3Wire.svg" alt="Wire" />
                                                    <div class="flex-column">
                                                        <div class="d-flex align-items-center flex-row">
                                                            <a href="/wire/"><p class="mb-0 product_id" onclick="redirectTo('/wire')">Wire</p></a>
                                                            <div class="docs-link ml-4 p-2 d-block" href="javascript:void((0)" onclick="getApiDocsFor('wire')">
                                                                API Docs <img class="link-icon ml-2" src="/static/base/assets_aug_2021/img/navMenu/arrow-right.svg" alt="" /></div>
                                                        </div>
                                                        <p class="nav-desc">Disburse payments via NEFT, RTGS, IMPS and UPI Handle</p>
                                                    </div>
                                                </a>
                                            </li>
                                            <li class="py-2 py-md-3 d-flex">
                                                <a class="d-flex align-items-center flex-row"><img class="nav-icon" src="/static/base/assets_aug_2021/img/easebuzz/about/instacollect.svg" alt="Wire" />
                                                    <div class="flex-column">
                                                        <div class="d-flex align-items-center flex-row">
                                                            <a href="/insta-collect">
                                                            <p class="mb-0 product_id" onclick="redirectTo('/insta-collect')">
                                                                InstaCollect</p></a>
                                                            <div class="docs-link ml-4 p-2 d-block" href="javascript:void((0)" onclick="getApiDocsFor('instaCollect')">
                                                                API Docs <img class="link-icon ml-2" src="/static/base/assets_aug_2021/img/navMenu/arrow-right.svg" alt="" /></div>
                                                        </div>
                                                        <p class="nav-desc">Collect payments instantly through virtual account.</p>
                                                    </div>
                                                </a>
                                            </li>
                                            <li class="py-2 py-md-3 d-flex">
                                                <a class="d-flex align-items-center flex-row" ><img class="nav-icon" src="/static/base/assets_aug_2021/img/navMenu/slices.svg" alt="slices" />
                                                    <div class="flex-column">
                                                        <div class="d-flex align-items-center flex-row">
                                                            <a href="/slices/">
                                                                <p class="mb-0 product_id" onclick="redirectTo('/slices')">
                                                                Slices</p>
                                                            </a>
                                                            <div class="docs-link ml-4 p-2 d-block" href="javascript:void((0)" onclick="getApiDocsFor('PaymentGateWay')">
                                                                API Docs <img class="link-icon ml-2" src="/static/base/assets_aug_2021/img/navMenu/arrow-right.svg" alt="" /></div>
                                                        </div>
                                                        <p class="nav-desc">Split payments to your vendors on every sale</p>
                                                    </div>
                                                </a>
                                            </li>
                                            <li class="py-2 py-md-3">
                                                <a class="d-flex align-items-center flex-row" href="/online-store/"><img class="nav-icon" src="/static/base/assets_aug_2021/img/navMenu/5Webstore.svg" alt="Webstore" />
                                                    <div class="flex-column">
                                                        <div class="d-flex align-items-center flex-row">
                                                            <p class="mb-0 product_id">Webstore</p>
                                                            <!-- <div class="docs-link ml-4 p-2 d-block" href="javascript:void(0)" onclick="getApiDocsFor()">
                                                                API Docs <img class="link-icon ml-2" src="/static/base/assets_aug_2021/img/navMenu/arrow-right.svg" alt="" /></div> -->
                                                        </div>
                                                        <p class="nav-desc">Create webstore of your products for FREE.</p>
                                                    </div>
                                                </a>
                                            </li>
                                            <li class="py-2 py-md-3">
                                                <a class="d-flex align-items-center flex-row" href="/international-payment-gateway/"><img class="nav-icon" src="/static/base/assets_aug_2021/img/navMenu/international-payment-gateway.svg" alt="International payment gateway" />
                                                    <div class="flex-column">
                                                        <div class="d-flex align-items-center flex-row">
                                                            <p class="mb-0 product_id">International Payment Gateway</p>
                                                            <!-- <div class="docs-link ml-4 p-2 d-block" href="javascript:void(0)" onclick="getApiDocsFor()">
                                                                API Docs <img class="link-icon ml-2" src="/static/base/assets_aug_2021/img/navMenu/arrow-right.svg" alt="" /></div> -->
                                                        </div>
                                                        <p class="nav-desc">Receive payments in rupees from across the globe</p>
                                                    </div>
                                                </a>
                                            </li>
                                        </ul>
                                    </div>
                                    <div class="item p-0 nav-menu-lists">
                                        <div class="nav-menu-lists-item">
                                            <h2 class="p-4 my-0">Value Added Service</h2>
                                        </div>
                                        <ul class="p-2 px-md-4 py-md-2 nav-menu-list-item">
                                            <!-- SAMPLE DATA-->
                                            <li class="py-2 py-md-3 d-flex">
                                                <a class="d-flex align-items-center flex-row"><img class="nav-icon" src="/static/base/assets_aug_2021/img/navMenu/6EasyCollect.svg" alt="EasyCollect" />
                                                    <div class="flex-column">
                                                        <div class="d-flex align-items-center flex-row">
                                                            <a href="/easy-collect/"><p class="mb-0 product_id" onclick="redirectTo('/easy-collect')">
                                                                EasyCollect</p></a>
                                                            <div class="docs-link ml-4 p-2 d-block" href="javascript:void(0)" onclick="getApiDocsFor('easyCollect')">
                                                                API Docs <img class="link-icon ml-2" src="/static/base/assets_aug_2021/img/navMenu/arrow-right.svg" alt="" /></div>
                                                        </div>
                                                        <p class="nav-desc">API based solution to manage subscription-based payments</p>
                                                    </div>
                                                </a>
                                            </li>
                                            <li class="py-2 py-md-3 d-flex">
                                                <a class="d-flex align-items-center flex-row"><img class="nav-icon" src="/static/base/assets_aug_2021/img/navMenu/7FeesBuzz.svg" alt="FeesBuzz" />
                                                    <div class="flex-column">
                                                        <div class="d-flex align-items-center flex-row">
                                                            <a href="/feesbuzz/"><p class="mb-0 product_id" onclick="redirectTo('/feesbuzz')">
                                                                FeesBuzz</p></a>
                                                            <div class="docs-link ml-4 p-2 d-block" href="javascript:void(0)" onclick="getApiDocsFor('feesBuzz')">
                                                                API Docs <img class="link-icon ml-2" src="/static/base/assets_aug_2021/img/navMenu/arrow-right.svg" alt="" /></div>
                                                        </div>
                                                        <p class="nav-desc">Collect fees installment wise using this API directly and have immediate reconciliation</p>
                                                    </div>
                                                </a>
                                            </li>
                                            <li class="py-2 py-md-3">
                                                <a class="d-flex align-items-center flex-row" href="/forms/"><img class="nav-icon" src="/static/base/assets_aug_2021/img/navMenu/8BuildBuzz.svg" alt="forms" />
                                                    <div class="flex-column">
                                                        <div class="d-flex align-items-center flex-row">
                                                            <p class="mb-0 product_id">Forms</p>
                                                            <!-- <div class="docs-link ml-4 p-2 d-block" href="javascript:void(0)" onclick="getApiDocsFor()">
                                                                API Docs <img class="link-icon ml-2" src="/static/base/assets_aug_2021/img/navMenu/arrow-right.svg"
                                                                 alt="" /></div> -->
                                                        </div>
                                                        <p class="nav-desc">Drag and Drop any form for your business registration process in 5 minutes</p>
                                                    </div>
                                                </a>
                                            </li>
                                            <li class="py-2 py-md-3 d-flex">
                                                <a class="d-flex align-items-center flex-row"><img class="nav-icon" src="/static/base/assets_aug_2021/img/navMenu/9SmartBilling.svg" alt="SmartBilling" />
                                                    <div class="flex-column">
                                                        <div class="d-flex align-items-center flex-row">
                                                            <a href="/smartbilling/"><p class="mb-0 product_id" onclick="redirectTo('/smartbilling')">
                                                                SmartBilling</p></a>
                                                            <div class="docs-link ml-4 p-2 d-block" href="javascript:void(0)" onclick="getApiDocsFor('smartBilling')">
                                                                API Docs <img class="link-icon ml-2" src="/static/base/assets_aug_2021/img/navMenu/arrow-right.svg" alt="" /></div>
                                                        </div>
                                                        <p class="nav-desc">Invoicing solution with E-nach and subscription plans</p>
                                                    </div>
                                                </a>
                                            </li>
                                            <li class="py-2 py-md-3">
                                                <a class="d-flex align-items-center flex-row" href="/teller/"><img class="nav-icon" src="/static/base/assets_aug_2021/img/navMenu/10Teller.svg" alt="Teller" />
                                                    <div class="flex-column">
                                                        <div class="d-flex align-items-center flex-row">
                                                            <p class="mb-0 product_id">Teller</p>
                                                            <!-- <div class="docs-link ml-4 p-2 d-block" href="javascript:void(0)" onclick="getApiDocsFor()">
                                                                API Docs <img class="link-icon ml-2" src="/static/base/assets_aug_2021/img/navMenu/arrow-right.svg"
                                                                 alt="" /></div> -->
                                                        </div>
                                                        <p class="nav-desc">A Fast, Easy &amp; Automated B2B Invoice management Solution</p>
                                                    </div>
                                                </a>
                                            </li>
                                            <li class="py-2 py-md-3 d-flex">
                                                <a class="d-flex align-items-center flex-row" href="/epos/"><img class="nav-icon" src="/static/base/assets_aug_2021/img/easebuzz/epos/epos.svg" alt="epos" />
                                                    <div class="flex-column">
                                                        <div class="d-flex align-items-center flex-row">
                                                            <p class="mb-0 product_id">ePOS</p>
                                                            <!-- <div class="docs-link ml-4 p-2 d-block" href="javascript:void(0)" onclick="getApiDocsFor()">
                                                                API Docs <img class="link-icon ml-2" src="/static/base/assets_aug_2021/img/navMenu/arrow-right.svg"
                                                                 alt="" /></div> -->
                                                        </div>
                                                        <p class="nav-desc">Instant payment collection from Easebuzz ePOS</p>
                                                    </div>
                                                </a>
                                            </li>
                                            <li class="py-2 py-md-3 d-flex">
                                                <a class="d-flex align-items-center flex-row" href="/recurri/"><img class="nav-icon" src="/static/base/assets_aug_2021/img/easebuzz/recurri/recurri-icon-active.svg" alt="recurri" />
                                                    <div class="flex-column">
                                                        <div class="d-flex align-items-center flex-row">
                                                            <p class="mb-0 product_id">Recurri</p>
                                                            <!-- <div class="docs-link ml-4 p-2 d-block" href="javascript:void(0)" onclick="getApiDocsFor()">
                                                                API Docs <img class="link-icon ml-2" src="/static/base/assets_aug_2021/img/navMenu/arrow-right.svg"
                                                                 alt="" /></div> -->
                                                        </div>
                                                        <p class="nav-desc">Subscriptions, Memberships, & Recurring Payments</p>
                                                    </div>
                                                </a>
                                            </li>
                                        </ul>
                                    </div>
                                    <div class="item p-0 nav-menu-lists">
                                        <div class="nav-menu-lists-item">
                                            <h2 class="p-4 my-0">Financial Service</h2>
                                        </div>
                                        <ul class="p-2 px-md-4 py-md-2 nav-menu-list-item">
                                            <!-- SAMPLE DATA-->
                                            <li class="py-2 py-md-3">
                                                <a class="d-flex align-items-center flex-row" href="/neo/"><img class="nav-icon" src="/static/base/assets_aug_2021/img/navMenu/Neo_Icon.svg" alt="EaseBuzz Neo" />
                                                    <div class="flex-column">
                                                        <div class="d-flex align-items-center flex-row">
                                                            <p class="mb-0 product_id">Easebuzz Neo</p>
                                                            <!-- <div class="docs-link ml-4 p-2 d-block" href="javascript:void(0)" onclick="getApiDocsFor()">
                                                                API Docs <img class="link-icon ml-2" src="/static/base/assets_aug_2021/img/navMenu/arrow-right.svg" alt="" /></div> -->
                                                        </div>
                                                        <p class="nav-desc">Smart Business Banking</p>
                                                    </div>
                                                </a>
                                            </li>
                                            <!-- <li class="py-2 py-md-3">
                                                <a class="d-flex align-items-center flex-row" href="/lending"><img class="nav-icon" src="/static/base/assets_aug_2021/img/navMenu/11EaseBuzzCaptial.svg" alt="EaseBuzz Capital" />
                                                    <div class="flex-column">
                                                        <div class="d-flex align-items-center flex-row">
                                                            <p class="mb-0 product_id">Easebuzz Capital</p>
                                                        </div>
                                                        <p class="nav-desc">Collateral-free working capital loans</p>
                                                    </div>
                                                </a>
                                            </li> -->
                                            <li class="py-2 py-md-3">
                                                <a class="d-flex align-items-center flex-row" href="/smartx-expense-management/"><img class="nav-icon" src="/static/base/assets_aug_2021/img/easebuzz/smartx/menu-icon.svg" alt="EaseBuzz Capital" />
                                                    <div class="flex-column">
                                                        <div class="d-flex align-items-center flex-row">
                                                            <p class="mb-0 product_id">Easebuzz SmartX</p>
                                                            <!-- <div class="docs-link ml-4 p-2 d-block" href="javascript:void(0)" onclick="getApiDocsFor()">
                                                                API Docs <img class="link-icon ml-2" src="/static/base/assets_aug_2021/img/navMenu/arrow-right.svg" alt="" /></div> -->
                                                        </div>
                                                        <p class="nav-desc">Expense Management Suite with Prepaid Cards</p>
                                                    </div>
                                                </a>
                                            </li>
                                            <li class="py-2 py-md-3">
                                                <a class="d-flex align-items-center flex-row" href="/tax-payments/"><img class="nav-icon" src="/static/base/assets_aug_2021/img/navMenu/tax_icon.svg" alt="EaseBuzz Capital" />
                                                    <div class="flex-column">
                                                        <div class="d-flex align-items-center flex-row">
                                                            <p class="mb-0 product_id">Tax Payments</p>
                                                            <!-- <div class="docs-link ml-4 p-2 d-block" href="javascript:void(0)" onclick="getApiDocsFor()">
                                                                API Docs <img class="link-icon ml-2" src="/static/base/assets_aug_2021/img/navMenu/arrow-right.svg" alt="" /></div> -->
                                                        </div>
                                                        <p class="nav-desc">Business Tax Payments - GST & Direct Tax</p>
                                                    </div>
                                                </a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </li>
                            <li class="menu__item only-mobile">
                                <h3 class="gradient-text mb-0 pr-3">Products</h3>
                                <div class="accordion navMenuList" id="navMenu">
                                    <div class="card">
                                        <div class="card-header" id="navMenuhead1"><a class="btn btn-header-link" href="#" data-toggle="collapse" data-target="#navMenu1" aria-expanded="true" aria-controls="navMenu1">Payments</a></div>
                                        <div class="collapse" id="navMenu1" aria-labelledby="navMenuhead1" data-parent="#navMenu">
                                            <div class="card-body">
                                                <ul class="p-2 px-md-4 py-md-2 nav-menu-list-item">
                                                    <!-- SAMPLE DATA-->
                                                    <li class="py-2 py-md-3">
                                                        <a class="d-flex align-items-center flex-row">
                                                            <img class="nav-icon" src="/static/base/assets_aug_2021/img/navMenu/1PaymentGateway.svg" alt="Payment Gateway" />
                                                            <div class="flex-column">
                                                                <div class="d-flex align-items-center flex-row">
                                                                    <p class="mb-0 product_id" onclick="redirectTo('/online-payment-gateway-India')"> 
                                                                        Payment Gateway</p>

                                                                    <div class="docs-link ml-4 p-2 d-block" onclick="getApiDocsFor('PaymentGateWay')">
                                                                        API Docs <img class="link-icon ml-2" src="/static/base/assets_aug_2021/img/navMenu/arrow-right.svg" alt="" /></div>
                                                                </div>
                                                                <p class="nav-desc">Accept payments with an API integration</p>
                                                            </div>
                                                        </a>
                                                    </li>
                                                    <li class="py-2 py-md-3">
                                                        <a class="d-flex align-items-center flex-row"><img class="nav-icon" src="/static/base/assets_aug_2021/img/navMenu/2PaymentLink.svg" alt="Payment Link" />
                                                            <div class="flex-column">
                                                                <div class="d-flex align-items-center flex-row">
                                                                    <p class="mb-0 product_id" onclick="redirectTo('/payment-links')">
                                                                        Payment Link</p>
                                                                    <!-- <div class="docs-link ml-4 p-2 d-block" onclick="getApiDocsFor()" href="javascript:void((0)">
                                                                        API Docs <img class="link-icon ml-2" src="/static/base/assets_aug_2021/img/navMenu/arrow-right.svg"
                                                                         alt="" /></div> -->
                                                                </div>
                                                                <p class="nav-desc">Accept payments via a link</p>
                                                            </div>
                                                        </a>
                                                    </li>
                                                    <li class="py-2 py-md-3">
                                                        <a class="d-flex align-items-center flex-row"><img class="nav-icon" src="/static/base/assets_aug_2021/img/navMenu/3Wire.svg" alt="Wire" />
                                                            <div class="flex-column">
                                                                <div class="d-flex align-items-center flex-row">
                                                                    <p class="mb-0 product_id" onclick="redirectTo('/wire')">
                                                                        Wire</p>
                                                                    <div class="docs-link ml-4 p-2 d-block" href="javascript:void((0)" onclick="getApiDocsFor('wire')">
                                                                        API Docs <img class="link-icon ml-2" src="/static/base/assets_aug_2021/img/navMenu/arrow-right.svg" alt="" /></div>
                                                                </div>
                                                                <p class="nav-desc">Disburse payments via NEFT, RTGS, IMPS and UPI Handle</p>
                                                            </div>
                                                        </a>
                                                    </li>
                                                    <li class="py-2 py-md-3">
                                                        <a class="d-flex align-items-center flex-row"><img class="nav-icon" src="/static/base/assets_aug_2021/img/easebuzz/about/instacollect.svg" alt="Wire" />
                                                            <div class="flex-column">
                                                                <div class="d-flex align-items-center flex-row">
                                                                    <p class="mb-0 product_id" onclick="redirectTo('/insta-collect/')">
                                                                        InstaCollect</p>
                                                                    <div class="docs-link ml-4 p-2 d-block" href="javascript:void((0)" onclick="getApiDocsFor('instaCollect')">
                                                                        API Docs <img class="link-icon ml-2" src="/static/base/assets_aug_2021/img/navMenu/arrow-right.svg" alt="" /></div>
                                                                </div>
                                                                <p class="nav-desc">Collect payments instantly through virtual account</p>
                                                            </div>
                                                        </a>
                                                    </li>
                                                    <li class="py-2 py-md-3">
                                                        <a class="d-flex align-items-center flex-row"><img class="nav-icon" src="/static/base/assets_aug_2021/img/navMenu/slices.svg" alt="slices" />
                                                            <div class="flex-column">
                                                                <div class="d-flex align-items-center flex-row">
                                                                    <p class="mb-0 product_id" onclick="redirectTo('/slices')">
                                                                        Slices</p>
                                                                    <div class="docs-link ml-4 p-2 d-block" href="javascript:void((0)" onclick="getApiDocsFor('PaymentGateWay')">
                                                                        API Docs <img class="link-icon ml-2" src="/static/base/assets_aug_2021/img/navMenu/arrow-right.svg" alt="" /></div>
                                                                </div>
                                                                <p class="nav-desc">Split payments to your vendors on every sale</p>
                                                            </div>
                                                        </a>
                                                    </li>
                                                    <li class="py-2 py-md-3">
                                                        <a class="d-flex align-items-center flex-row" href="/online-store/"><img class="nav-icon" src="/static/base/assets_aug_2021/img/navMenu/5Webstore.svg" alt="Webstore" />
                                                            <div class="flex-column">
                                                                <div class="d-flex align-items-center flex-row">
                                                                    <p class="mb-0 product_id">Webstore</p>
                                                                    <!-- <div class="docs-link ml-4 p-2 d-block" href="javascript:void((0)" onclick="getApiDocsFor()">
                                                                        API Docs <img class="link-icon ml-2" src="/static/base/assets_aug_2021/img/navMenu/arrow-right.svg" alt="" /></div> -->
                                                                </div>
                                                                <p class="nav-desc">Create webstore of your products for FREE.</p>
                                                            </div>
                                                        </a>
                                                    </li>
                                                    <li class="py-2 py-md-3">
                                                        <a class="d-flex align-items-center flex-row" href="/international-payment-gateway/"><img class="nav-icon" src="/static/base/assets_aug_2021/img/navMenu/international-payment-gateway.svg" alt="International payment gateway" />
                                                            <div class="flex-column">
                                                                <div class="d-flex align-items-center flex-row">
                                                                    <p class="mb-0 product_id">International Payment Gateway</p>
                                                                    <!-- <div class="docs-link ml-4 p-2 d-block" href="javascript:void((0)" onclick="getApiDocsFor()">
                                                                        API Docs <img class="link-icon ml-2" src="/static/base/assets_aug_2021/img/navMenu/arrow-right.svg" alt="" /></div> -->
                                                                </div>
                                                                <p class="nav-desc">Receive payments in rupees from across the globe</p>
                                                            </div>
                                                        </a>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="card">
                                        <div class="card-header" id="navMenuhead2"><a class="btn btn-header-link" href="#" data-toggle="collapse" data-target="#navMenu2" aria-expanded="true" aria-controls="navMenu2">Value Added Service</a></div>
                                        <div class="collapse" id="navMenu2" aria-labelledby="navMenuhead2" data-parent="#navMenu">
                                            <div class="card-body">
                                                <ul class="p-2 px-md-4 py-md-2 nav-menu-list-item">
                                                    <!-- SAMPLE DATA-->
                                                    <li class="py-2 py-md-3">
                                                        <a class="d-flex align-items-center flex-row"><img class="nav-icon" src="/static/base/assets_aug_2021/img/navMenu/6EasyCollect.svg" alt="EasyCollect" />
                                                            <div class="flex-column">
                                                                <div class="d-flex align-items-center flex-row">
                                                                    <p class="mb-0 product_id" onclick="redirectTo('/easy-collect')">
                                                                        EasyCollect</p>
                                                                    <div class="docs-link ml-4 p-2 d-block" href="javascript:void((0)" onclick="getApiDocsFor('easyCollect')">
                                                                        API Docs <img class="link-icon ml-2" src="/static/base/assets_aug_2021/img/navMenu/arrow-right.svg" alt="" /></div>
                                                                </div>
                                                                <p class="nav-desc">API based solution to manage subscription-based payments</p>
                                                            </div>
                                                        </a>
                                                    </li>
                                                    <li class="py-2 py-md-3">
                                                        <a class="d-flex align-items-center flex-row"><img class="nav-icon" src="/static/base/assets_aug_2021/img/navMenu/7FeesBuzz.svg" alt="FeesBuzz" />
                                                            <div class="flex-column">
                                                                <div class="d-flex align-items-center flex-row">
                                                                    <p class="mb-0 product_id" onclick="redirectTo('/feesbuzz')">
                                                                        FeesBuzz</p>
                                                                    <div class="docs-link ml-4 p-2 d-block" href="javascript:void((0)" onclick="getApiDocsFor('feesBuzz')">
                                                                        API Docs <img class="link-icon ml-2" src="/static/base/assets_aug_2021/img/navMenu/arrow-right.svg" alt="" /></div>
                                                                </div>
                                                                <p class="nav-desc">Collect fees installment wise using this API directly and have immediate reconciliation</p>
                                                            </div>
                                                        </a>
                                                    </li>
                                                    <li class="py-2 py-md-3">
                                                        <a class="d-flex align-items-center flex-row" href="/forms/"><img class="nav-icon" src="/static/base/assets_aug_2021/img/navMenu/8BuildBuzz.svg" alt="forms" />
                                                            <div class="flex-column">
                                                                <div class="d-flex align-items-center flex-row">
                                                                    <p class="mb-0 product_id">Forms</p>
                                                                    <!-- <div class="docs-link ml-4 p-2 d-block" href="javascript:void((0)" onclick="getApiDocsFor()">
                                                                        API Docs <img class="link-icon ml-2" src="/static/base/assets_aug_2021/img/navMenu/arrow-right.svg"
                                                                         alt="" /></div> -->
                                                                </div>
                                                                <p class="nav-desc">Drag and Drop any form for your business registration process in 5 minutes</p>
                                                            </div>
                                                        </a>
                                                    </li>
                                                    <li class="py-2 py-md-3">
                                                        <a class="d-flex align-items-center flex-row"><img class="nav-icon" src="/static/base/assets_aug_2021/img/navMenu/9SmartBilling.svg" alt="SmartBilling" />
                                                            <div class="flex-column">
                                                                <div class="d-flex align-items-center flex-row">
                                                                    <p class="mb-0 product_id" onclick="redirectTo('/smartbilling')">
                                                                        SmartBilling</p>
                                                                    <div class="docs-link ml-4 p-2 d-block" href="javascript:void((0)" onclick="getApiDocsFor('smartBilling')">
                                                                        API Docs <img class="link-icon ml-2" src="/static/base/assets_aug_2021/img/navMenu/arrow-right.svg" alt="" /></div>
                                                                </div>
                                                                <p class="nav-desc">Invoicing solution with E-nach and subscription plans</p>
                                                            </div>
                                                        </a>
                                                    </li>
                                                    <li class="py-2 py-md-3">
                                                        <a class="d-flex align-items-center flex-row" href="/teller/"><img class="nav-icon" src="/static/base/assets_aug_2021/img/navMenu/10Teller.svg" alt="Teller" />
                                                            <div class="flex-column">
                                                                <div class="d-flex align-items-center flex-row">
                                                                    <p class="mb-0 product_id">Teller</p>
                                                                    <!-- <div class="docs-link ml-4 p-2 d-block" href="javascript:void((0)" onclick="getApiDocsFor()">
                                                                        API Docs <img class="link-icon ml-2" src="/static/base/assets_aug_2021/img/navMenu/arrow-right.svg" 
                                                                        alt="" /></div> -->
                                                                </div>
                                                                <p class="nav-desc">A Fast, Easy &amp; Automated B2B Invoice management Solution</p>
                                                            </div>
                                                        </a>
                                                    </li>
                                                    <li class="py-2 py-md-3">
                                                        <a class="d-flex align-items-center flex-row" href="/epos/"><img class="nav-icon" src="/static/base/assets_aug_2021/img/easebuzz/epos/epos.svg" alt="epos" />
                                                            <div class="flex-column">
                                                                <div class="d-flex align-items-center flex-row">
                                                                    <p class="mb-0 product_id">ePOS</p>
                                                                    <!-- <div class="docs-link ml-4 p-2 d-block" href="javascript:void((0)" onclick="getApiDocsFor()">
                                                                        API Docs <img class="link-icon ml-2" src="/static/base/assets_aug_2021/img/navMenu/arrow-right.svg" 
                                                                        alt="" /></div> -->
                                                                </div>
                                                        <p class="nav-desc">Instant payment collection from Easebuzz ePOS</p>
                                                        
                                                            </div>
                                                        </a>
                                                    </li>
                                                    <li class="py-2 py-md-3">
                                                        <a class="d-flex align-items-center flex-row" href="/recurri/"><img class="nav-icon" src="/static/base/assets_aug_2021/img/easebuzz/recurri/recurri-icon-active.svg" alt="recurri" />
                                                            <div class="flex-column">
                                                                <div class="d-flex align-items-center flex-row">
                                                                    <p class="mb-0 product_id">Recurri</p>
                                                                    <!-- <div class="docs-link ml-4 p-2 d-block" href="javascript:void((0)" onclick="getApiDocsFor()">
                                                                        API Docs <img class="link-icon ml-2" src="/static/base/assets_aug_2021/img/navMenu/arrow-right.svg" 
                                                                        alt="" /></div> -->
                                                                </div>
                                                        <p class="nav-desc">Subscriptions, Memberships, & Recurring Payments</p>
                                                        
                                                            </div>
                                                        </a>
                                                    </li>
                                                     
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="card">
                                        <div class="card-header" id="navMenuhead3"><a class="btn btn-header-link" href="#" data-toggle="collapse" data-target="#navMenu3" aria-expanded="true" aria-controls="navMenu3">Financial Service</a></div>
                                        <div class="collapse" id="navMenu3" aria-labelledby="navMenuhead3" data-parent="#navMenu">
                                            <div class="card-body">
                                                <ul class="p-2 px-md-4 py-md-2 nav-menu-list-item">
                                                    <!-- SAMPLE DATA-->
                                                    <li class="py-2 py-md-3">
                                                        <a class="d-flex align-items-center flex-row" href="/neo/"><img class="nav-icon" src="/static/base/assets_aug_2021/img/navMenu/Neo_Icon.svg" alt="EaseBuzz Neo" />
                                                            <div class="flex-column">
                                                                <div class="d-flex align-items-center flex-row">
                                                                    <p class="mb-0 product_id">Easebuzz Neo</p>
                                                                    <!-- <div class="docs-link ml-4 p-2 d-block" href="javascript:void(0)" onclick="getApiDocsFor()">
                                                                        API Docs <img class="link-icon ml-2" src="/static/base/assets_aug_2021/img/navMenu/arrow-right.svg" alt="" /></div> -->
                                                                </div>
                                                                <p class="nav-desc">Smart Business Banking</p>
                                                            </div>
                                                        </a>
                                                    </li>
                                                    <!-- <li class="py-2 py-md-3">
                                                        <a class="d-flex align-items-center flex-row" href="/lending"><img class="nav-icon" src="/static/base/assets_aug_2021/img/navMenu/11EaseBuzzCaptial.svg" alt="EaseBuzz Capital" />
                                                            <div class="flex-column">
                                                                <div class="d-flex align-items-center flex-row">
                                                                    <p class="mb-0 product_id">Easebuzz Capital</p>
                                                                </div>
                                                                <p class="nav-desc">Collateral-free working capital loans</p>
                                                            </div>
                                                        </a>
                                                    </li> -->
                                                    <li class="py-2 py-md-3">
                                                        <a class="d-flex align-items-center flex-row" href="/smartx-expense-management/"><img class="nav-icon" src="/static/base/assets_aug_2021/img/easebuzz/smartx/menu-icon.svg" alt="EaseBuzz Capital" />
                                                            <div class="flex-column">
                                                                <div class="d-flex align-items-center flex-row">
                                                                    <p class="mb-0 product_id">Easebuzz SmartX</p>
                                                                   <!-- <div class="docs-link ml-4 p-2 d-block" href="javascript:void((0)" onclick="getApiDocsFor()">
                                                                        API Docs <img class="link-icon ml-2" src="/static/base/assets_aug_2021/img/navMenu/arrow-right.svg" alt="" /></div> -->
                                                                </div>
                                                                <p class="nav-desc">Expense Management Suite with Prepaid Cards
                                                                </p>
                                                            </div>
                                                        </a>
                                                    </li>
                                                    <li class="py-2 py-md-3">
                                                        <a class="d-flex align-items-center flex-row" href="/tax-payments/"><img class="nav-icon" src="/static/base/assets_aug_2021/img/navMenu/tax_icon.svg" alt="EaseBuzz Capital" />
                                                            <div class="flex-column">
                                                                <div class="d-flex align-items-center flex-row">
                                                                    <p class="mb-0 product_id">Tax Payments</p>
                                                                   <!-- <div class="docs-link ml-4 p-2 d-block" href="javascript:void((0)" onclick="getApiDocsFor()">
                                                                        API Docs <img class="link-icon ml-2" src="/static/base/assets_aug_2021/img/navMenu/arrow-right.svg" alt="" /></div> -->
                                                                </div>
                                                                <p class="nav-desc">Business Tax Payments - GST & Direct Tax</p>
                                                            </div>
                                                        </a>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </li>
                            <!-- use cases desktop -->
                            <li class="menu__item ui dropdown header-select-dropdown-company">
                                <input type="hidden" name="Company" />
                                <div class="d-flex align-items-center menu__link">
                                    <div class="default nav-dropdown-text pr-3">Use Cases</div><svg width="9" height="12" viewBox="0 0 9 12" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M4.53001 11.8646L8.04725 8.96791C8.3155 8.72826 8.34112 8.34398 8.13459 8.09175C7.92807 7.83951 7.51066 7.79795 7.25845 8.00451L4.7563 10.0671L4.7563 0.62071C4.7563 0.277903 4.47841 -1.65801e-07 4.13562 -1.80784e-07C3.79282 -1.95769e-07 3.51493 0.277903 3.51493 0.62071L3.51493 10.0671L1.01277 8.00451C0.760582 7.79795 0.349019 7.84444 0.13664 8.09175C-0.0823807 8.34676 -0.0282721 8.76141 0.223976 8.96791L3.74121 11.8646C4.00635 12.0531 4.27362 12.037 4.53001 11.8646Z" fill="white"/>
</svg>

                                </div>
                                <div class="menu transition hidden header-select-dropdown-company__menu p-4">
                                    <!-- SAMPLE DATA-->
                                    <ul class="item p-2 px-md-4 py-md-2 nav-menu-list-item">
                                        <li class="py-2 py-md-3">
                                            <a class="d-flex align-items-center flex-row" href="/use-cases/education/"><img class="nav-icon" src="/static/base/assets_aug_2021/img/use-cases-icon/edu.svg" alt="Help Desk" />
                                                <div class="flex-column">
                                                    <div class="d-flex align-items-center flex-row">
                                                        <p class="mb-0 product_id">Education</p>
                                                    </div>
                                                </div>
                                            </a>
                                        </li>
                                        <li class="py-2 py-md-3">
                                            <a class="d-flex align-items-center flex-row" href="/use-cases/ecommerce/">
                                                <img class="nav-icon" src="/static/base/assets_aug_2021/img/use-cases-icon/eccom.svg" alt="About Us" />
                                                <div class="flex-column">
                                                    <div class="d-flex align-items-center flex-row">
                                                        <p class="mb-0 product_id">Ecommerce</p>
                                                    </div>
                                                </div>
                                            </a>
                                        </li>
                                        <li class="py-2 py-md-3">
                                            <a class="d-flex align-items-center flex-row" href="/use-cases/real-estate/"><img class="nav-icon" src="/static/base/assets_aug_2021/img/use-cases-icon/real-estate.svg" alt="Contact Us" />
                                                <div class="flex-column">
                                                    <div class="d-flex align-items-center flex-row">
                                                        <p class="mb-0 product_id">Real Estate</p>
                                                    </div>
                                                </div>
                                            </a>
                                        </li>
                                        <li class="py-2 py-md-3">
                                            <a class="d-flex align-items-center flex-row" href="/use-cases/marketplace/"><img class="nav-icon" src="/static/base/assets_aug_2021/img/use-cases-icon/market.svg" alt="Partner" />
                                                <div class="flex-column">
                                                    <div class="d-flex align-items-center flex-row">
                                                        <p class="mb-0 product_id">Marketplace</p>
                                                    </div>
                                                </div>
                                            </a>
                                        </li>
                                        <li class="py-2 py-md-3">
                                            <a class="d-flex align-items-center flex-row" href="/use-cases/saas-and-erp/"><img class="nav-icon" src="/static/base/assets_aug_2021/img/use-cases-icon/saas.svg" alt="Blogs" />
                                                <div class="flex-column">
                                                    <div class="d-flex align-items-center flex-row">
                                                        <p class="mb-0 product_id">SaaS & ERP</p>
                                                    </div>
                                                </div>
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                            </li>
                            <li class="menu__item ui dropdown header-select-dropdown-company">
                                <input type="hidden" name="Company" />
                                <div class="d-flex align-items-center menu__link">
                                    <div class="default nav-dropdown-text pr-3">Company</div><svg width="9" height="12" viewBox="0 0 9 12" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M4.53001 11.8646L8.04725 8.96791C8.3155 8.72826 8.34112 8.34398 8.13459 8.09175C7.92807 7.83951 7.51066 7.79795 7.25845 8.00451L4.7563 10.0671L4.7563 0.62071C4.7563 0.277903 4.47841 -1.65801e-07 4.13562 -1.80784e-07C3.79282 -1.95769e-07 3.51493 0.277903 3.51493 0.62071L3.51493 10.0671L1.01277 8.00451C0.760582 7.79795 0.349019 7.84444 0.13664 8.09175C-0.0823807 8.34676 -0.0282721 8.76141 0.223976 8.96791L3.74121 11.8646C4.00635 12.0531 4.27362 12.037 4.53001 11.8646Z" fill="white"/>
</svg>

                                </div>
                                <div class="menu transition hidden header-select-dropdown-company__menu p-4">
                                    <!-- SAMPLE DATA-->
                                    <ul class="item p-2 px-md-4 py-md-2 nav-menu-list-item">
                                        <li class="py-2 py-md-3">
                                            <a class="d-flex align-items-center flex-row" href="/about/">
                                                <img class="nav-icon" src="/static/base/assets_aug_2021/img/navMenu/company/Aboutus.svg" alt="About Us" />
                                                <div class="flex-column">
                                                    <div class="d-flex align-items-center flex-row">
                                                        <p class="mb-0 product_id">About Us</p>
                                                    </div>
                                                </div>
                                            </a>
                                        </li>
                                        <li class="py-2 py-md-3">
                                            <a class="d-flex align-items-center flex-row" href="https://blog.easebuzz.in/" target="_blank"><img class="nav-icon" src="/static/base/assets_aug_2021/img/navMenu/company/Blogs.svg" alt="Blogs" />
                                                <div class="flex-column">
                                                    <div class="d-flex align-items-center flex-row">
                                                        <p class="mb-0 product_id">Blogs</p>
                                                    </div>
                                                </div>
                                            </a>
                                        </li>
                                        <li class="py-2 py-md-3">
                                            <a class="d-flex align-items-center flex-row" href="https://helpdesk.easebuzz.in/merchant/transaction" target="_blank"><img class="nav-icon" src="/static/base/assets_aug_2021/img/navMenu/company/HelpDesk.svg" alt="Help Desk" />
                                                <div class="flex-column">
                                                    <div class="d-flex align-items-center flex-row">
                                                        <p class="mb-0 product_id">Help Desk</p>
                                                    </div>
                                                </div>
                                            </a>
                                        </li>
                                        <li class="py-2 py-md-3">
                                            <a class="d-flex align-items-center flex-row" href="/partner/"><img class="nav-icon" src="/static/base/assets_aug_2021/img/navMenu/company/Partner.svg" alt="Partner" />
                                                <div class="flex-column">
                                                    <div class="d-flex align-items-center flex-row">
                                                        <p class="mb-0 product_id">Partner</p>
                                                    </div>
                                                </div>
                                            </a>
                                        </li>
                                        <li class="py-2 py-md-3">
                                            <a class="d-flex align-items-center flex-row" href="/contact/"><img class="nav-icon" src="/static/base/assets_aug_2021/img/navMenu/company/Contactus.svg" alt="Contact Us" />
                                                <div class="flex-column">
                                                    <div class="d-flex align-items-center flex-row">
                                                        <p class="mb-0 product_id">Contact Us</p>
                                                    </div>
                                                </div>
                                            </a>
                                        </li>
                                        <li class="py-2 py-md-3">
                                            <a class="d-flex align-items-center flex-row" href="/customer-stories/"><img class="nav-icon" src="/static/base/assets_aug_2021/img/navMenu/company/customer_stories.svg" alt="Customer Testimonial" />
                                                <div class="flex-column">
                                                    <div class="d-flex align-items-center flex-row">
                                                        <p class="mb-0 product_id">Customer Stories</p>
                                                    </div>
                                                </div>
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                            </li>
                                  <!-- use case mobile section -->
                                  <li class="menu__item only-mobile">
                                    <div class="accordion navMenuList" id="navMenu">
                                        <div class="card">
                                            <div class="card-header" id="navMenuhead12"><a class="btn btn-header-link" href="#" data-toggle="collapse" data-target="#navMenu11" aria-expanded="true" aria-controls="navMenu10">Use Cases</a></div>
                                            <div class="collapse" id="navMenu11" aria-labelledby="navMenuhead12" data-parent="#navMenu">
                                                <div class="card-body">
                                                    <!-- SAMPLE DATA-->
                                                    <ul class="item p-2 px-md-4 py-md-2 nav-menu-list-item">
                                                        <li class="py-2 py-md-3">
                                                            <a class="d-flex align-items-center flex-row" href="/use-cases/education/" ><img class="nav-icon" src="/static/base/assets_aug_2021/img/use-cases-icon/edu.svg" alt="Help Desk" />
                                                                <div class="flex-column">
                                                                    <div class="d-flex align-items-center flex-row">
                                                                        <p class="mb-0 product_id">Education</p>
                                                                    </div>
                                                                </div>
                                                            </a>
                                                        </li>
                                                        <li class="py-2 py-md-3">
                                                            <a class="d-flex align-items-center flex-row" href="/use-cases/ecommerce/"><img class="nav-icon" src="/static/base/assets_aug_2021/img/use-cases-icon/eccom.svg" alt="About Us" />
                                                                <div class="flex-column">
                                                                    <div class="d-flex align-items-center flex-row">
                                                                        <p class="mb-0 product_id">Ecommerce</p>
                                                                    </div>
                                                                </div>
                                                            </a>
                                                        </li>
                                                        <li class="py-2 py-md-3">
                                                            <a class="d-flex align-items-center flex-row" href="/use-cases/real-estate/"><img class="nav-icon" src="/static/base/assets_aug_2021/img/use-cases-icon/real-estate.svg" alt="Contact Us" />
                                                                <div class="flex-column">
                                                                    <div class="d-flex align-items-center flex-row">
                                                                        <p class="mb-0 product_id">Real Estate</p>
                                                                    </div>
                                                                </div>
                                                            </a>
                                                        </li>
                                                        <li class="py-2 py-md-3">
                                                            <a class="d-flex align-items-center flex-row" href="/use-cases/marketplace/"><img class="nav-icon" src="/static/base/assets_aug_2021/img/use-cases-icon/market.svg" alt="Partner" />
                                                                <div class="flex-column">
                                                                    <div class="d-flex align-items-center flex-row">
                                                                        <p class="mb-0 product_id">Marketplace</p>
                                                                    </div>
                                                                </div>
                                                            </a>
                                                        </li>
                                                        <li class="py-2 py-md-3">
                                                            <a class="d-flex align-items-center flex-row" href="/use-cases/saas-and-erp" ><img class="nav-icon" src="/static/base/assets_aug_2021/img/use-cases-icon/saas.svg" alt="Blogs" />
                                                                <div class="flex-column">
                                                                    <div class="d-flex align-items-center flex-row">
                                                                        <p class="mb-0 product_id">SaaS & ERP</p>
                                                                    </div>
                                                                </div>
                                                            </a>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </li>
    
                            <li class="menu__item only-mobile">
                                <div class="accordion navMenuList" id="navMenu">
                                    <div class="card">
                                        <div class="card-header" id="navMenuhead11"><a class="btn btn-header-link" href="#" data-toggle="collapse" data-target="#navMenu10" aria-expanded="true" aria-controls="navMenu10">Company</a></div>
                                        <div class="collapse" id="navMenu10" aria-labelledby="navMenuhead11" data-parent="#navMenu">
                                            <div class="card-body">
                                                <!-- SAMPLE DATA-->
                                                <ul class="item p-2 px-md-4 py-md-2 nav-menu-list-item">
                                                    <li class="py-2 py-md-3">
                                                        <a class="d-flex align-items-center flex-row" href="/about/"><img class="nav-icon" src="/static/base/assets_aug_2021/img/navMenu/company/Aboutus.svg" alt="About Us" />
                                                            <div class="flex-column">
                                                                <div class="d-flex align-items-center flex-row">
                                                                    <p class="mb-0 product_id">About Us</p>
                                                                </div>
                                                            </div>
                                                        </a>
                                                    </li>
                                                    <li class="py-2 py-md-3">
                                                        <a class="d-flex align-items-center flex-row" href="https://blog.easebuzz.in/" target="_blank"><img class="nav-icon" src="/static/base/assets_aug_2021/img/navMenu/company/Blogs.svg" alt="Blogs" />
                                                            <div class="flex-column">
                                                                <div class="d-flex align-items-center flex-row">
                                                                    <p class="mb-0 product_id">Blogs</p>
                                                                </div>
                                                            </div>
                                                        </a>
                                                    </li>
                                                    <li class="py-2 py-md-3">
                                                        <a class="d-flex align-items-center flex-row" href="https://helpdesk.easebuzz.in/merchant/transaction" target="_blank"><img class="nav-icon" src="/static/base/assets_aug_2021/img/navMenu/company/HelpDesk.svg" alt="Help Desk" />
                                                            <div class="flex-column">
                                                                <div class="d-flex align-items-center flex-row">
                                                                    <p class="mb-0 product_id">Help Desk</p>
                                                                </div>
                                                            </div>
                                                        </a>
                                                    </li>
                                                    <li class="py-2 py-md-3">
                                                        <a class="d-flex align-items-center flex-row" href="/partner/"><img class="nav-icon" src="/static/base/assets_aug_2021/img/navMenu/company/Partner.svg" alt="Partner" />
                                                            <div class="flex-column">
                                                                <div class="d-flex align-items-center flex-row">
                                                                    <p class="mb-0 product_id">Partner</p>
                                                                </div>
                                                            </div>
                                                        </a>
                                                    </li>
                                                    <li class="py-2 py-md-3">
                                                        <a class="d-flex align-items-center flex-row" href="/contact/"><img class="nav-icon" src="/static/base/assets_aug_2021/img/navMenu/company/Contactus.svg" alt="Contact Us" />
                                                            <div class="flex-column">
                                                                <div class="d-flex align-items-center flex-row">
                                                                    <p class="mb-0 product_id">Contact Us</p>
                                                                </div>
                                                            </div>
                                                        </a>
                                                    </li>
                                                    <li class="py-2 py-md-3">
                                                        <a class="d-flex align-items-center flex-row" href="/customer-stories/"><img class="nav-icon" src="/static/base/assets_aug_2021/img/navMenu/company/customer_stories.svg" alt="Customer Testimonial" />
                                                            <div class="flex-column">
                                                                <div class="d-flex align-items-center flex-row">
                                                                    <p class="mb-0 product_id">Customer Stories</p>
                                                                </div>
                                                            </div>
                                                        </a>
                                                    </li>
                                                    
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </li>
                    

                            <li class="menu__item"><a class="menu__link" href="/pricing/">Pricing</a></li>
                            <li class="menu__item"><a class="menu__link" href="https://docs.easebuzz.in/" target="_blank">Developers</a></li>
                            <!-- <li class="menu__item"><a class="menu__link" href="javascript:void((0)">Resources</a></li> -->
                            
                            
                                <li class="menu__item"><a class="menu__link" href="/merchant/login/">Sign In</a></li>
                                <li class="menu__item header-sign-up"><a class="sign-up" href="/merchant/signup/">Sign Up</a></li>
                            
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </nav>
</header>

<script>
    // document.getElementById("hiring_banner").style.display = 'none';
 

    function getApiDocsFor(id){
    
        switch (id) {
            case "PaymentGateWay":
                window.open("https://docs.easebuzz.in/docs/payment-gateway/","_blank");        
                break;
            case "wire":
                window.open("https://docs.easebuzz.in/docs/neobanking/", "_blank")
                break; 

            case "easyCollect":
                window.open("https://docs.easebuzz.in/docs/payment-gateway/eulenqaaji2bf/", "_blank")
                break;  

            case "instaCollect":
                window.open("https://docs.easebuzz.in/docs/neobanking/", "_blank")
                break; 

            case "feesBuzz":
                window.open("https://docs.easebuzz.in/docs/feesbuzz/", "_blank")
                break; 
            
            case "smartBilling":
                window.open("https://docs.easebuzz.in/docs/smartbilling/", "_blank")
                break;
                
            default:
                window.open("https://docs.easebuzz.in/","_blank");
                break;
        }
        
    }

    function redirectTo(url){
        $(location).attr('href', url);
    }
    

    
 </script>



</body>
</html> 
    
    <!-- Header End -->

    <!-- Banner Area Start -->
    
    
    <!-- Banner area Start -->

    <!-- Main content area end -->
    
        <!-- LOADER-->
    <main class="js-common-animations js-home-animations js-footer-gsap">
        <div class="page-loader" style="width: 100%;height: 100%;position: fixed;background: #ffffff;z-index: 10000;left: 0;top: 0;"></div>
        <section class="error-spacing gsap-section-trig"> 
            <div class="container"> 
              <div class="row gseamless"> 
                <div class="col-12 col-lg-6 p-0">
                  <div class="gseamless-img"><img src="/static/base/assets_aug_2021/img/home/404error.svg" class="img-creative" alt=""/></div>
                </div>
                <div class="col-12 col-lg-6 mr-auto">
                  <div class="gseamless-right">
                    <h4 class="heading heading--black price-heading gsap-heading">404 page!</h4>
                    <h4 class="heading heading--black price-heading gsap-heading">
                      <span class="oops">
                        Oops! You ran into a wrong URL
                      </span>
                    </h4>
                    <p class="small-text small-text--black gsap-desc">
                      It looks like the page doesn’t exist – please check the URL and try again.</p>
                    </p>
                    <p class="small-text small-text--black gsap-desc">
                        Can’t find what you were looking for?</p>
                      <div>
                        <a href="/">
                          <p class="small-text gsap-desc hy-link">
                            Learn about our products
                              <img class="ml-2" src="/static/base/assets_aug_2021/img/easebuzz/home/purple-right.svg" alt=""/>
                          </p>
                        </a>
                        <a href="/demo/">
                          <p class="small-text gsap-desc hy-link">
                            Demo Payment page 
                              <img class="ml-2" src="/static/base/assets_aug_2021/img/easebuzz/home/purple-right.svg" alt=""/>
                          </p>
                        </a>
                        <a href="https://blog.easebuzz.in/" target="_blank">
                          <p class="small-text gsap-desc hy-link"> 
                            Read our Blog
                              <img class="ml-2" src="/static/base/assets_aug_2021/img/easebuzz/home/purple-right.svg" alt=""/>
                          </p>
                        </a>
                        <a href="/about/">
                          <p class="small-text gsap-desc hy-link"> 
                            About Easebuzz 
                              <img class="ml-2" src="/static/base/assets_aug_2021/img/easebuzz/home/purple-right.svg" alt=""/>
                          </p>
                        </a>
                      </div>
                  </div>
                </div>
              </div>
            </div>
          </section>
    </main>
 
    
    <!-- Main content area end -->

    <!-- Footer start -->
     
        
<footer id="footerSection">
    <div class="container">
        <div class="row footer-top">
            <div class="col-md-12">
                <div class="footer-logo">
                    <a href="/">
                        <img class="footer-logo__img"
                            src="/static/base/assets_aug_2021/img/easebuzz/home/logo-red.svg"
                            alt="easebuzz-logo" />
                    </a>
                </div>
            </div>
        </div>
        <ul class="row d-flex flex-wrap footer-list gsap-list-item pl-0">
            <li class="footer-list__item col-md-12 col-lg-4 mb-5 pr-md-5">
                <p class="footer-text mb-0">Easebuzz is a software enabled payments platform that is helping small
                    businesses to digitise payments without worrying about their business process problems. Early-stage
                    growth companies face complex business scenarios as they grow and
                    end up with high-cost centers for solving such issues with banks or other financial institutions.
                    Easebuzz helps you with smart APIs and cost-effective solutions all at 1 single place.
                    Scale-up your Business with Easebuzz Payment Solutions Platform
                </p>

                <div class="footer-media mdLg-only">
                    <div class="subscribe-box">
                        <p class="footer-subhead">Subscribe to our newsletter</p>
                        <form class="footer__form" id="formEmail" action="">
                            <input class="footer__form__input" id="subscriber_email" type="text"
                                data-parsley-type="email" placeholder="Your Email Address" />
                            <p><span style="color: red;" id="err_msg"></span></p>
                            <p><span style="color: green;" id="succ_msg"></span></p>
                            <button class="footer__submit" type="button"
                                onclick="subscribe_to_newsletter()">Submit</button>
                        </form>
                    </div>
                    <div class="footer-media-bottom mb-md-4">
                        <p class="footer-subhead">Follow us on</p>
                        <ul class="footer-media-list pl-0">
                            <li class="footer-media-list__item">
                                <a class="media-link" href="https://www.facebook.com/Easebuzz.in/" target="_blank">
                                    <img class="media-icon"
                                        src="/static/base/assets_aug_2021/img/easebuzz/home/icon1.svg"
                                        alt="features" /></a>
                            </li>
                            <li class="footer-media-list__item">
                                <a class="media-link"
                                    href="https://www.linkedin.com/company/easebuzz/?originalSubdomain=in"
                                    target="_blank">
                                    <img class="media-icon"
                                        src="/static/base/assets_aug_2021/img/easebuzz/home/icon2.svg"
                                        alt="features" /></a>
                            </li>
                            <li class="footer-media-list__item">
                                <a class="media-link" href="https://twitter.com/Easebuzz"
                                    target="_blank"> <img class="media-icon" style="width: 22px;"
                                        src="/static/base/assets_aug_2021/img/easebuzz/home/twitter-icon.svg"
                                        alt="features" />
                                </a>
                            </li> 
                            <li class="footer-media-list__item">
                                <a class="media-link" href="https://www.youtube.com/channel/UCzafjIZHvrCfOlu_0No288A"
                                    target="_blank">
                                    <img class="media-icon"
                                        src="/static/base/assets_aug_2021/img/easebuzz/home/icon4.svg"
                                        alt="features" /></a>
                            </li>
                        </ul>
                    </div>
                </div>
            </li>
            <li class="footer-list__item col-md-3 col-lg-2">
                <h3 class="footer-head">Products</h3>
                <ul class="footer-nav-list">
                    <li class="footer-nav-list__item"><a class="footer__link" href="/neo/">Easebuzz Neo</a></li>
                    <li class="footer-nav-list__item"><a class="footer__link" href="/online-payment-gateway-India/">Payment Gateway</a></li>
                    <li class="footer-nav-list__item"><a class="footer__link" href="/payment-links/">Payment Link</a></li>
                    <li class="footer-nav-list__item"><a class="footer__link" href="/wire/">Wire</a></li>
                    <li class="footer-nav-list__item"><a class="footer__link" href="/insta-collect/">InstaCollect</a></li>
                    <li class="footer-nav-list__item"><a class="footer__link" href="/slices/">Slices</a></li>
                    <li class="footer-nav-list__item"><a class="footer__link" href="/online-store/">Webstore</a></li>
                    <li class="footer-nav-list__item"><a class="footer__link" href="/easy-collect/">EasyCollect</a></li>
                    <li class="footer-nav-list__item"><a class="footer__link" href="/feesbuzz/">FeesBuzz</a></li>
                    <li class="footer-nav-list__item"><a class="footer__link" href="/forms/">Forms</a></li>
                    <li class="footer-nav-list__item"><a class="footer__link" href="/smartbilling/">SmartBilling</a></li>
                    <li class="footer-nav-list__item"><a class="footer__link" href="/teller/">Teller</a></li>
                    <li class="footer-nav-list__item"><a class="footer__link" href="/epos/">ePOS</a></li>
                    <li class="footer-nav-list__item"><a class="footer__link" href="/shopify-payment-gateway/">Shopify</a></li>
                    <li class="footer-nav-list__item"><a class="footer__link" href="/vendor-payments/">Vendor Payments</a></li>
                    <li class="footer-nav-list__item"><a class="footer__link" href="/smartx-expense-management/">Easebuzz SmartX</a></li>
                    <li class="footer-nav-list__item"><a class="footer__link" href="/tax-payments/">Tax Payments</a></li>
                    <li class="footer-nav-list__item"><a class="footer__link" href="/recurri/">Recurri</a></li>
                    <li class="footer-nav-list__item"><a class="footer__link" href="/upi-payment-gateway/">UPI Payment Gateway</a></li>

                    <li class="footer-nav-list__item"><a class="footer__link" href="/soundbar/">Soundbar</a></li>
                </ul>
            </li>
            
            <li class="footer-list__item col-md-3 col-lg-2">
                <ul class="footer-nav-list">
                    <h3 class="footer-head">Merchant Onboarding</h3>
                    <li class="footer-nav-list__item"><a class="footer__link" target="_blank"
                            href="https://docs.easebuzz.in/docs/get-started/6v6i0r0x14zly-kyc-documents">KYC Documents
                            Checklist</a></li>
                    <h3 class="footer-head footer-developers">Developers</h3>
                    <li class="footer-nav-list__item"><a class="footer__link" href="https://docs.easebuzz.in/"
                            target="_blank">Documentation</a></li>
                    <li class="footer-nav-list__item"><a class="footer__link" href="https://github.com/Easebuzz/"
                            target="_blank">Github</a></li>
                    <li class="footer-nav-list__item"><a class="footer__link" href="/features/">Features</a>
                    </li>
                    <h3 class="footer-head use-case-footer">Use Cases</h3>

                    <li class="footer-nav-list__item"><a class="footer__link"
                            href="/use-cases/ecommerce/">Ecommerce</a></li>
                    <li class="footer-nav-list__item"><a class="footer__link"
                            href="/use-cases/saas-and-erp/">SaaS & ERP</a></li>
                    <li class="footer-nav-list__item"><a class="footer__link"
                            href="/use-cases/education/">Education</a></li>
                    <li class="footer-nav-list__item"><a class="footer__link"
                            href="/use-cases/marketplace/">Marketplace</a></li>
                    <li class="footer-nav-list__item"><a class="footer__link"
                            href="/use-cases/real-estate/">Real Estate</a></li>
                </ul>
            </li>
            <li class="footer-list__item col-md-3 col-lg-2">
                <h3 class="footer-head">Company</h3>
                <ul class="footer-nav-list">
                    <li class="footer-nav-list__item"><a class="footer__link" href="/about/">About Us</a></li>
                    <li class="footer-nav-list__item"><a class="footer__link" href="/partner/">Partner</a></li>
                    <li class="footer-nav-list__item"><a class="footer__link" href="https://blog.easebuzz.in/">Blog</a></li>
                    <li class="footer-nav-list__item"><a class="footer__link" href="/careers" >Careers</a></li>
                    <li class="footer-nav-list__item"><a class="footer__link" href="https://helpdesk.easebuzz.in/" target="_blank">Helpdesk</a></li>
                    <li class="footer-nav-list__item"><a class="footer__link" href="/security">Security</a></li>
                    <li class="footer-nav-list__item"><a class="footer__link" href="/disclaimer/">Disclaimer</a></li>
                    <li class="footer-nav-list__item"><a class="footer__link" href="/disclosures/">Disclosures</a></li>
                    <li class="footer-nav-list__item"><a class="footer__link" href="/iccPosh/">ICC under POSH</a></li>
                </ul>
            </li>
            
            <li class="footer-list__item col-md-3 col-lg-2 pr-0">
                <h3 class="footer-head">Resources</h3>
                <ul class="footer-nav-list">
                    <li class="footer-nav-list__item"><a class="footer__link" href="/contact/">Contact Us</a></li>
                    <li class="footer-nav-list__item"><a class="footer__link" href="/terms/">Terms and Conditions</a></li>
                    <li class="footer-nav-list__item"><a class="footer__link" href="/explainers/">Easebuzz Explainers</a></li>
                    <li class="footer-nav-list__item"><a class="footer__link" href="/how-payment-works/">How Payments Works</a></li>
                    <li class="footer-nav-list__item"><a class="footer__link" href="/privacy/">Privacy</a></li>
                    <li class="footer-nav-list__item"><a class="footer__link" href="/grievance">Grievance Redressal</a></li>
                    <h3 class="footer-head Newsletter-footer">Newsletter</h3>
                    <ul class="footer-nav-list">
                        <li class="footer-nav-list__item">
                            <a class="footer__link" href="/newsletter/buzzing-for-bharat/q2fy23" target="_blank">Buzzing for भारत</a>
                        </li>
                    </ul>
                </ul>
            </li>
            
        </ul>
        <div class="row">
            <div class="col-12 footer-media smLg-only">
                <div class="subscribe-box">
                    <p class="footer-subhead">Subscribe to our Newsletter</p>
                    <form class="footer__form" action="">
                        <input class="footer__form__input" id="subscriber_email_mobile_view" type="text"
                            data-parsley-type="email" placeholder="Your Email Address" />
                        <p><span style="color: red;" id="err_msg_mobile_view"></span></p>
                        <p><span style="color: green;" id="succ_msg_mobile_view"></span></p>
                        <button class="footer__submit" type="button"
                            onclick="subscribe_to_newsletter_mobile_view()">Submit</button>
                    </form>
                </div>
                <div class="footer-media-bottom mb-md-4">
                    <p class="footer-subhead">Follow us on</p>
                    <ul class="footer-media-list">
                        <li class="footer-media-list__item">
                            <a class="media-link" href="https://www.facebook.com/Easebuzz.in/" target="_blank"> <img
                                    class="media-icon"
                                    src="/static/base/assets_aug_2021/img/easebuzz/home/icon1.svg"
                                    alt="features" /></a>
                        </li>
                        <li class="footer-media-list__item">
                            <a class="media-link" href="https://www.linkedin.com/company/easebuzz/?originalSubdomain=in"
                                target="_blank"> <img class="media-icon"
                                    src="/static/base/assets_aug_2021/img/easebuzz/home/icon2.svg"
                                    alt="features" /></a>
                        </li>
                        <li class="footer-media-list__item">
                            <a class="media-link" href="https://twitter.com/Easebuzz"
                                target="_blank"> <img class="media-icon" style="width: 22px;"
                                    src="/static/base/assets_aug_2021/img/easebuzz/home/twitter-icon.svg"
                                    alt="features" /></a>
                        </li> 
                        <li class="footer-media-list__item">
                            <a class="media-link" href="https://www.youtube.com/channel/UCzafjIZHvrCfOlu_0No288A"
                                target="_blank"> <img class="media-icon"
                                    src="/static/base/assets_aug_2021/img/easebuzz/home/icon4.svg"
                                    alt="features" /></a>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="row col-12 footer-bottom align-items-lg-end">
                <div class="col-lg-8 col-md-12 col-xl-8">
                    <div class="footer-bottom-left">
                        <p class="footer-subhead"> Download our app</p>
                        <ul class="download-list">
                            <li class="download-list__item">
                                <a class="media-link" href="https://apps.apple.com/in/app/easebuzz-epos/id6444483364" target="_blank"> <img
                                        class="media-icon"
                                        src="/static/base/assets_aug_2021/img/easebuzz/home/icon5.svg"
                                        alt="features" /></a>
                            </li>
                            <li class="download-list__item">
                                <a class="media-link" href="https://play.google.com/store/apps/details?id=com.easebuzz.epos" target="_blank"> <img
                                        class="media-icon"
                                        src="/static/base/assets_aug_2021/img/easebuzz/home/android.svg"
                                        alt="features" /></a>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-4 col-md-12 col-xl-4">
                    <p class="copyright-text mb-0">© 2023 Easebuzz | All rights reserved</p>
                </div>
            </div>
        </div>
    </div>
</footer>


<script>
    function subscribe_to_newsletter() {
        $("#succ_msg").html("")
        var email = $("#subscriber_email").val();
        var error_msg = ""
        const re = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        if (email) {
            if (re.test(email)) {
                error_msg = ""
                data = {
                    "subscription_email": email
                }
                $.get("/news-subscription/", data, function (response) {
                    if (response.status) {
                        $("#succ_msg").html(response.msg)
                    }
                    else {
                        $("#err_msg").html(response.msg)
                    }
                });
            }
            else {
                error_msg = "Please enter valid email."
            }
        }
        else {
            error_msg = "Please enter email."
        }
        $("#err_msg").html(error_msg)
    }
    function subscribe_to_newsletter_mobile_view() {
        $("#succ_msg_mobile_view").html("")
        var email = $("#subscriber_email_mobile_view").val();
        var error_msg = ""
        const re = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        if (email) {
            if (re.test(email)) {
                error_msg = ""
                data = {
                    "subscription_email": email
                }
                $.get("/news-subscription/", data, function (response) {
                    if (response.status) {
                        $("#succ_msg_mobile_view").html(response.msg)
                    }
                    else {
                        $("#err_msg_mobile_view").html(response.msg)
                    }
                });
            }
            else {
                error_msg = "Please enter valid email."
            }
        }
        else {
            error_msg = "Please enter email."
        }
        $("#err_msg_mobile_view").html(error_msg)
    } 
</script>

 
    
    <!-- Footer end -->

    <!-- extra footer content payment-gateway start -->
    
    
    <!-- extra footer content payment-gateway end -->

    <!-- extra footer content payment-link start -->
    
    
    <!-- extra footer content payment-link end -->

    <!-- extra footer content feesbuzz start -->
    
    
    <!-- extra footer content feesbuzz end -->

    <!-- Javascript area start -->
        
    <!-- <script src="/static/base/assets_aug_2021/js/modernizr.min.js"></script> -->
    <script src="/static/base/assets_aug_2021/js/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
    <!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script> -->
    <script src="/static/base/assets_aug_2021/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <script defer="defer" src="/static/base/assets_aug_2021/js/load.js"></script>
    <script src="/static/base/assets_aug_2021/js/gsap.min.js"></script>
    <!--  -->
    <script src="/static/base/assets_aug_2021/js/ScrollTrigger.min.js"></script>
    <!--  -->
    <!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/parsley.js/2.8.0/parsley.min.js"></script> -->
    <script defer="defer" src="/static/base/assets_aug_2021/js/plugins/swiper.js"></script>
    <script defer="defer" src="/static/base/assets_aug_2021/js/semantic_ui_min.js"></script>
    <script defer="defer" src="/static/base/assets_aug_2021/js/common.js"></script>
    <!-- <script defer="defer" src="https://cdnjs.cloudflare.com/ajax/libs/prism/0.0.1/prism.min.js"></script> -->
    <!-- <script defer="defer" src="https://s3-us-west-2.amazonaws.com/s.cdpn.io/769286/jquery.waitforimages.min.js"></script> -->
    <script defer="defer" src="/static/base/assets_aug_2021/js/lottie.min.js"></script>
    <script defer="defer" src="/static/base/assets_aug_2021/js/home.js"></script>
    <script defer="defer" src="/static/base/assets_aug_2021/js/home-new.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

 
    
    
    
    <!-- Javascript area end -->

    <script type="text/javascript">
        _linkedin_partner_id = "3759364";
        window._linkedin_data_partner_ids = window._linkedin_data_partner_ids || [];
        window._linkedin_data_partner_ids.push(_linkedin_partner_id);
        </script><script type="text/javascript">
        (function(l) {
        if (!l){window.lintrk = function(a,b){window.lintrk.q.push([a,b])};
        window.lintrk.q=[]}
        var s = document.getElementsByTagName("script")[0];
        var b = document.createElement("script");
        b.type = "text/javascript";b.async = true;
        b.src = "https://snap.licdn.com/li.lms-analytics/insight.min.js";
        s.parentNode.insertBefore(b, s);})(window.lintrk);
        </script>
        <noscript>
        <img height="1" width="1" style="display:none;" alt="" src="https://px.ads.linkedin.com/collect/?pid=3759364&fmt=gif" />
    </noscript>

</body>

</html>